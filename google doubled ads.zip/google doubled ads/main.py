from kivy.app import App
from kivy.uix.screenmanager import ScreenManager
from kivy.uix.screenmanager import Screen
import json
import hashlib
import requests

class Manager(ScreenManager):
    pass


class MainWindow(Screen):
    def texthash(self, keyad = ''):
        '''generates a hash from a text passed from the input field (TextInput) in the GUI'''

        a = hashlib.sha1()
        keyad = bytes(keyad, encoding='utf-8')
        a.update(keyad)
        self.ids.hashres.text = a.hexdigest()
        return a.hexdigest()

    def urlhash(self, keylp = ''):
        '''Hashes a url - since this is a PoC, no screenshot hash feature is present at this time.'''
        if 'http://' not in keylp:
            keylp = 'http://'+keylp
        print(keylp)
        b = hashlib.sha256()
        page = requests.get(keylp)
        hashlib.sha256(page.text.encode('utf-8')).hexdigest()
        self.ids.hashres.text = b.hexdigest()
        return b.hexdigest()

    def testhasher(self, path):
        '''hashes a file. Since we don't know how Google deals the ads (if they are a file, a mix of text, images and so on)
        this might be usefull if they treat ads as files).'''


        try:
            with open(path, 'rb') as image1:
                hasher = hashlib.sha1()
                buf = image1.read()
                hasher.update(buf)
                self.ids.hashres.text = hasher.hexdigest()
                return hasher.hexdigest()

        except: self.ids.hashres.text = str(FileNotFoundError('File Not Found'))

    def databaseadd(self, decision, hashres, hashimg="", hashurl=""):
        '''this reads and writes decisions from the JSON file database. This format was chosen for it's speed in data transfer
        between server and client. Loads of room to improve here'''

        try:
            with open("database.json", "r") as file:
                a = json.load(file)
                print(a)
                b = {hashres:{}}
                b[hashres] = decision
                print(b)
                a.update(b)
                print(a)

            with open("database.json", 'w') as file1:
                json.dump(a, file1, indent=4)

        except: FileNotFoundError('File Not Found')

    def checkid(self, hash_id):
        '''this checks if an ad exists in the database. If it does, this prints the pair 'key, value' which associates
         with the hash of the ad and the decision taken by an agent.'''
        try:
            with open("database.json", "r") as file2:
                db = json.load(file2)
                for k, v in db.items():
                    if k == hash_id:
                        print(k, v)
                        self.ids.hashres.text = str(v)
                    else:
                        pass
        except: FileNotFoundError('File not found')

class Doubledads(App):
    def build(self):
        sm = Manager()
        sm.add_widget(MainWindow(name='window1'))
        return sm


if __name__ == "__main__":
    Doubledads().run()

'''
reviewed 5 times a cluster of 900 ads of the same shoe company with the same violations. 
this is time consuming and inefficient. 
hash technology in a simple database would solve this issue easily, saving us time, achieving a better TAT. 
empresa de sapatos na internet
'''