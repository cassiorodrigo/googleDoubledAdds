'''import requests
import hashlib
while True:

    page = requests.get(str(input('Qual página?\n')))
    print(hashlib.sha256(page.text.encode('utf-8')).hexdigest())

'''
def test(a = 0, b=0, c=''):
    print(b)
    print(a+b)
    print(a-b)


test(a=1, b=2)

import json
from random import randint
ident = randint(999, 9999)

with open("teste1.json", "r") as file:
    b = json.load(file)
    a = {ident:{}}
    a[ident]["nome"] = "Cassio"
    a[ident]["idade"] = 33
    print(a)
    b.update(a)
    print(b)

with open("teste1.json", "w") as file1:
    json.dump(b, file1, indent=4)
